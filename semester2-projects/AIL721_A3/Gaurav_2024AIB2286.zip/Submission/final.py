import sys
import os
import time
import re
import string
import nltk
import numpy as np
import pandas as pd
from collections import Counter

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

import tensorflow as tf
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import SparseCategoricalCrossentropy
from tensorflow.keras.metrics import SparseCategoricalAccuracy
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import (Embedding, GlobalAveragePooling1D, Dense,
                                     Dropout, LSTM, Bidirectional, LayerNormalization, 
                                     MultiHeadAttention, Input)
from gensim.models import KeyedVectors
from sklearn.metrics import f1_score


gpus = tf.config.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        logical_gpus = tf.config.list_logical_devices('GPU')
    except RuntimeError as e:
        print(f"Error setting memory growth: {e}")
else:
    print("No GPU .. using CPU.")


nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('stopwords')

def is_colab():
    return 'google.colab' in sys.modules

def clean_text(text):
    stop_words = set(stopwords.words('english'))
    text = text.lower()
    tokens = word_tokenize(text)
    tokens = [token for token in tokens if token.isalnum() and not token.isnumeric()]
    tokens = [token for token in tokens if token not in stop_words]
    cleaned_text = " ".join(tokens)
    return cleaned_text.strip()

# -------- Constants --------
MAX_LEN = 850
BATCH_SIZE = 32
PAD_TOKEN = "<PAD>"
UNK_TOKEN = "<UNK>"

train_path = "TrainData.csv"
test_path = "TestLabels.csv"

if is_colab():
    drive_base = "/content/drive/MyDrive/"
    train_path = os.path.join(drive_base, "Shared/IITD/SEM2/AIL721/assign3/TrainData.csv")
    test_path = os.path.join(drive_base, "Shared/IITD/SEM2/AIL721/assign3/TestLabels.csv")
    base_embed_path = os.path.join(drive_base, "gensim_models") 
else:
    base_embed_path = "~/scratch/"


print("---Loading Data ---")
try:
    df_train = pd.read_csv(train_path)
    df_test = pd.read_csv(test_path, usecols=[1, 2])
except FileNotFoundError as e:
    print(f"ERROR: Could not find data file: {e}")
    print("Please ensure the file paths are correct:")
    print(f"Train path: {train_path}")
    print(f"Test path: {test_path}")
    sys.exit(1)

df_train.columns = ['Text', 'Label']
df_test.columns = ['Text', 'Label']
print(f"Initial train shape: {df_train.shape}")
print(f"Initial test shape: {df_test.shape}")
df_train.dropna(subset=['Text', 'Label'], inplace=True)
df_test.dropna(subset=['Text', 'Label'], inplace=True)
df_train['Text'] = df_train['Text'].astype(str)
df_test['Text'] = df_test['Text'].astype(str)
print(f"Train shape after dropna: {df_train.shape}")
print(f"Test shape after dropna: {df_test.shape}")

print("Train Data Head:")
print(df_train.head())
print("\nTest Data Head:")
print(df_test.head())
print("-" * 30)

print("\n---Data Preprocessing ---")
df_train['Cleaned_Text'] = df_train['Text'].apply(clean_text)
df_test['Cleaned_Text'] = df_test['Text'].apply(clean_text)
print("Sample Cleaned Text (Train):")
print(df_train[['Text', 'Cleaned_Text']].head())
df_train['Tokens'] = df_train['Cleaned_Text'].apply(word_tokenize)
df_test['Tokens'] = df_test['Cleaned_Text'].apply(word_tokenize)
print("Sample Tokenized Text (Train):")
print(df_train[['Cleaned_Text', 'Tokens']].head())
all_train_tokens = [token for sublist in df_train['Tokens'] for token in sublist]
from collections import Counter
token_counts = Counter(all_train_tokens)
unique_tokens = sorted(token_counts.keys())

word_to_idx = {PAD_TOKEN: 0, UNK_TOKEN: 1}
current_idx = 2
for token in unique_tokens:
    if token not in word_to_idx:
        word_to_idx[token] = current_idx
        current_idx += 1

idx_to_word = {idx: word for word, idx in word_to_idx.items()}
vocab_size = len(word_to_idx)
print(f"Vocabulary Size (including {PAD_TOKEN} and {UNK_TOKEN}): {vocab_size}")
print("First 20 actual words in vocab:", list(word_to_idx.items())[2:22])

print("\n2.d Label Encoding...")
from sklearn.preprocessing import LabelEncoder
label_encoder = LabelEncoder()
df_train['Label_Encoded'] = label_encoder.fit_transform(df_train['Label'])
df_test['Label_Encoded'] = label_encoder.transform(df_test['Label'])
num_classes = len(label_encoder.classes_)
print(f"Number of Classes: {num_classes}")
print("Label Mapping:", dict(zip(label_encoder.classes_, range(num_classes))))
print("Sample Encoded Labels (Train):")
print(df_train[['Label', 'Label_Encoded']].head())
print("-" * 30)

unk_idx = word_to_idx[UNK_TOKEN]
pad_idx = word_to_idx[PAD_TOKEN]

def convert_tokens_to_padded_ids(token_lists, labels, word2idx, max_len, pad_value, unk_value):
    numeric_sequences = []
    for tokens in token_lists:
        token_ids = [word2idx.get(tok, unk_value) for tok in tokens]
        if len(token_ids) > max_len:
            token_ids = token_ids[:max_len]
        numeric_sequences.append(token_ids)
    
    padded_sequences = tf.keras.preprocessing.sequence.pad_sequences(
        numeric_sequences,
        maxlen=max_len,
        padding='post',
        value=pad_value
    )
    return np.array(padded_sequences), np.array(labels)

X_train_np, y_train_np = convert_tokens_to_padded_ids(
    token_lists=df_train['Tokens'].tolist(),
    labels=df_train['Label_Encoded'].tolist(),
    word2idx=word_to_idx,
    max_len=MAX_LEN,
    pad_value=pad_idx,
    unk_value=unk_idx
)

X_test_np, y_test_np = convert_tokens_to_padded_ids(
    token_lists=df_test['Tokens'].tolist(),
    labels=df_test['Label_Encoded'].tolist(),
    word2idx=word_to_idx,
    max_len=MAX_LEN,
    pad_value=pad_idx,
    unk_value=unk_idx
)

print(f"X_train_np shape: {X_train_np.shape}, y_train_np shape: {y_train_np.shape}")
print(f"X_test_np shape: {X_test_np.shape}, y_test_np shape: {y_test_np.shape}")
print("-" * 30)

print("\n--- 5. Embedding Handling ---")
def load_gensim_embedding(path, binary=False, limit=None):
    print(f"Attempting to load embeddings from: {path}")
    if not os.path.exists(path):
        print(f"File not found: {path}. Skipping.")
        return None
    try:
        model = KeyedVectors.load_word2vec_format(path, binary=binary, limit=limit)
        print(f"Loaded {len(model.key_to_index)} vectors from {os.path.basename(path)}.")
        return model
    except Exception as e:
        print(f"Error loading embedding file {path}: {e}")
        return None

def build_embedding_matrix(word_index, vocab_size, embedding_dim, pretrained_model):
    if pretrained_model is None:
        print("No pre-trained model provided, embedding matrix not built.")
        return None
    if pretrained_model.vector_size != embedding_dim:
        print(f"ERROR: Dimension mismatch. Pretrained model has dim {pretrained_model.vector_size}, requested {embedding_dim}")
        return None

    print(f"Building embedding matrix with dimension: {embedding_dim}")
    embedding_matrix = np.random.uniform(-0.05, 0.05, (vocab_size, embedding_dim)).astype(np.float32)
    hits = 0
    misses = 0
    for word, i in word_index.items():
        if i >= vocab_size: 
            continue
        if i == pad_idx:
            embedding_matrix[i] = np.zeros(embedding_dim, dtype=np.float32)
            continue
        if word in pretrained_model:
            try:
                embedding_matrix[i] = pretrained_model[word]
                hits += 1
            except KeyError:
                misses += 1
        else:
            misses += 1

    print(f"Embedding Matrix Ready: Shape {embedding_matrix.shape}. Found {hits} words, missed {misses} words.")
    return embedding_matrix

print("\nPre-building Embedding Matrices...")
SCRATCH_EMBED_DIM = 128

embedding_paths = {
    'glove': '/home/scai/mtech/aib242286/scratch/glove-wiki-gigaword-100.gz',
    'fasttext': '/home/scai/mtech/aib242286/scratch/fasttext-wiki-news-subwords-300.gz',
    'word2vec': '/home/scai/mtech/aib242286/scratch/word2vec-google-news-300.gz'
}
embedding_binary_flags = {
    'glove': False,
    'fasttext': False,
    'word2vec': True
}
embedding_dims = {
    'glove': 100,
    'fasttext': 300,
    'word2vec': 300,
    'scratch': SCRATCH_EMBED_DIM
}

embedding_matrices = {}
pretrained_models = {}

for name, path in embedding_paths.items():
    print(f"\n--- Processing Embedding: {name.upper()} ---")
    emb_dim = embedding_dims[name]
    is_binary = embedding_binary_flags[name]
    model = load_gensim_embedding(path, binary=is_binary)
    pretrained_models[name] = model
    if model:
        matrix = build_embedding_matrix(word_to_idx, vocab_size, emb_dim, model)
        embedding_matrices[name] = {'matrix': matrix, 'dim': emb_dim}
    else:
        embedding_matrices[name] = {'matrix': None, 'dim': emb_dim}
        print(f"Could not load or build matrix for {name}. Models using it will fail or use random embeddings.")

embedding_matrices['scratch'] = {'matrix': None, 'dim': SCRATCH_EMBED_DIM}
print("\nEmbedding Matrix preparation finished.")
print("-" * 30)


print("\n--- 6. Defining Keras Models ---")

from gensim.models import KeyedVectors
import gc

class TransformerEncoder(tf.keras.layers.Layer):
    def __init__(self, embed_dim, num_heads, dense_dim, dropout_rate=0.1, **kwargs):
        super().__init__(**kwargs)
        self.attention = MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim, dropout=dropout_rate)
        self.dropout1 = Dropout(dropout_rate)
        self.norm1 = LayerNormalization(epsilon=1e-6)
        self.ffn = tf.keras.Sequential([Dense(dense_dim, activation='relu'), Dense(embed_dim)])
        self.dropout2 = Dropout(dropout_rate)
        self.norm2 = LayerNormalization(epsilon=1e-6)

    def call(self, inputs, training=False, attention_mask=None):
        if attention_mask is not None:
            attention_mask = tf.cast(tf.expand_dims(attention_mask, axis=1), tf.float32)
        attn_output = self.attention(query=inputs, value=inputs, key=inputs, attention_mask=attention_mask, training=training)
        out1 = self.norm1(inputs + self.dropout1(attn_output, training=training))
        ffn_output = self.ffn(out1, training=training)
        return self.norm2(out1 + self.dropout2(ffn_output, training=training))

class TransformerClassifier(Model):
    def __init__(self, vocab_size, embed_dim, max_len, num_heads, ff_dim, num_transformer_blocks,
                 num_classes, dropout_rate=0.1, embedding_matrix=None, freeze_embeddings=True,
                 use_positional_emb=True, name="transformer_classifier", **kwargs):
        super().__init__(name=name, **kwargs)
        self.use_positional_emb = use_positional_emb
        self.max_len = max_len
        self.embed_dim = embed_dim
        self.num_classes = num_classes
        self.num_transformer_blocks = num_transformer_blocks

        self.token_embedding = Embedding(input_dim=vocab_size, output_dim=embed_dim, input_length=max_len,
                                         weights=[embedding_matrix] if embedding_matrix is not None else None,
                                         trainable=not freeze_embeddings if embedding_matrix is not None else True,
                                         mask_zero=True)
        if use_positional_emb:
            self.pos_embedding = Embedding(input_dim=max_len, output_dim=embed_dim)
        else:
            self.pos_embedding = None

        self.embedding_dropout = Dropout(dropout_rate)
        self.encoder_blocks = [
            TransformerEncoder(embed_dim=embed_dim, num_heads=num_heads, dense_dim=ff_dim, dropout_rate=dropout_rate)
            for _ in range(num_transformer_blocks)
        ]
        self.global_avg_pool = GlobalAveragePooling1D()
        self.final_dropout = Dropout(dropout_rate)
        self.dense_out = Dense(num_classes)

    def call(self, inputs, training=False):
        mask = self.token_embedding.compute_mask(inputs)
        x = self.token_embedding(inputs)
        if self.use_positional_emb and self.pos_embedding:
            positions = tf.range(start=0, limit=self.max_len, delta=1)
            position_embeddings = self.pos_embedding(positions)
            x += position_embeddings
        x = self.embedding_dropout(x, training=training)
        for encoder in self.encoder_blocks:
            x = encoder(x, training=training, attention_mask=mask)
        x = self.global_avg_pool(x)
        x = self.final_dropout(x, training=training)
        return self.dense_out(x)

    def build_graph(self):
        x = Input(shape=(self.max_len,), dtype=tf.int32)
        return Model(inputs=x, outputs=self.call(x))

    def get_config(self):
        config = {
            'vocab_size': self.token_embedding.input_dim,
            'embed_dim': self.embed_dim,
            'max_len': self.max_len,
            'num_heads': self.encoder_blocks[0].num_heads if self.num_transformer_blocks > 0 else 0,
            'ff_dim': self.encoder_blocks[0].dense_dim if self.num_transformer_blocks > 0 else 0,
            'num_transformer_blocks': self.num_transformer_blocks,
            'num_classes': self.num_classes,
            'dropout_rate': self.embedding_dropout.rate,
            'use_positional_emb': self.use_positional_emb,
            'freeze_embeddings': not self.token_embedding.trainable,
            'name': self.name
        }
        return config

TRANSFORMER_HEADS = 4
TRANSFORMER_FF_DIM = 256
TRANSFORMER_DROPOUT = 0.1
TRANSFORMER_LR = 3e-4
EPOCHS = 15
BATCH_SIZE = 32

def build_bilstm_model(vocab_size, embedding_dim, max_len, num_classes,
                       embedding_matrix=None, freeze_embeddings=True, use_attention=False,
                       lstm_units=64, dropout_rate=0.3):
    """bidirectional lstm"""
    model = Sequential(name=f"BiLSTM_Emb{embedding_dim}_Units{lstm_units}")
    model.add(Input(shape=(max_len,), dtype='int32', name="input"))
    model.add(Embedding(
        input_dim=vocab_size,
        output_dim=embedding_dim,
        input_length=max_len,
        weights=[embedding_matrix] if embedding_matrix is not None else None,
        trainable=not freeze_embeddings if embedding_matrix is not None else True,
        mask_zero=True,
        name="embedding"
    ))
    model.add(Bidirectional(LSTM(lstm_units, dropout=dropout_rate, recurrent_dropout=dropout_rate), 
               name="bidirectional_lstm"))
    model.add(Dropout(dropout_rate, name="dropout_before_dense"))
    model.add(Dense(num_classes, activation=None, name="output_dense"))
    return model

print("-" * 30)
bilstm_experiments = [
    {'name': 'BiLSTM_GloVe', 'embedding_type': 'glove', 'use_attention': False},
    {'name': 'BiLSTM_FastText', 'embedding_type': 'fasttext', 'use_attention': False},
    {'name': 'BiLSTM_Word2Vec', 'embedding_type': 'word2vec', 'use_attention': False},
    {'name': 'BiLSTM_Scratch', 'embedding_type': 'scratch', 'use_attention': False},
    {'name': 'BiLSTM_GloVe_atn', 'embedding_type': 'glove', 'use_attention': True},
    {'name': 'BiLSTM_FastText_atn', 'embedding_type': 'fasttext', 'use_attention': True},
    {'name': 'BiLSTM_Word2Vec_atn', 'embedding_type': 'word2vec', 'use_attention': True},
    {'name': 'BiLSTM_Scratch_atn', 'embedding_type': 'scratch', 'use_attention': True},
]
#bilstm_experiments = [] # remove this line to run bilstm exp aizceq

results_list = []
EPOCHS = 10
LEARNING_RATE = 1e-3

early_stopping = EarlyStopping(monitor='val_loss', patience=4, verbose=0, restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=2, min_lr=1e-6, verbose=0)
callbacks_list = []

print("\n=== Starting BiLSTM Experiments ===")
for config in bilstm_experiments:
    print(f"\n{'='*10} Running BiLSTM Experiment: {config['name']} {'='*10}")
    start_time = time.time()

    emb_type = config['embedding_type']
    emb_info = embedding_matrices.get(emb_type)
    if not emb_info:
        print(f"ERROR: Embedding info for '{emb_type}' not found. Skipping.")
        continue

    emb_matrix = emb_info['matrix']
    emb_dim = emb_info['dim']
    freeze_embeddings = (emb_type != 'scratch' and emb_matrix is not None)

    tf.keras.backend.clear_session()

    model = build_bilstm_model(
        vocab_size=vocab_size,
        embedding_dim=emb_dim,
        max_len=MAX_LEN,
        num_classes=num_classes,
        embedding_matrix=emb_matrix,
        freeze_embeddings=freeze_embeddings,
        use_attention=config['use_attention']
    )

    model.compile(
        optimizer=Adam(learning_rate=LEARNING_RATE),
        loss=SparseCategoricalCrossentropy(from_logits=True),
        metrics=[SparseCategoricalAccuracy(name='accuracy')]
    )

    print("\nModel Summary:")
    model.summary()
    print(f"\nTraining {config['name']}...")
    print(f"X_train: {X_train_np.shape}, y_train: {y_train_np.shape}")
    print(f"X_test: {X_test_np.shape}, y_test: {y_test_np.shape}")
    history = model.fit(
        X_train_np, y_train_np,
        validation_data=(X_test_np, y_test_np),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=callbacks_list,
        verbose=0
    )

    print(f"\nEvaluating {config['name']}...")
    test_loss, test_accuracy = model.evaluate(X_test_np, y_test_np, batch_size=BATCH_SIZE*2, verbose=0)
    y_pred_logits = model.predict(X_test_np, batch_size=BATCH_SIZE*2)
    y_pred_classes = np.argmax(y_pred_logits, axis=1)

    test_f1_micro = f1_score(y_test_np, y_pred_classes, average='micro', zero_division=0)
    test_f1_macro = f1_score(y_test_np, y_pred_classes, average='macro', zero_division=0)

    end_time = time.time()
    duration = end_time - start_time

    epochs_run = len(history.history['loss']) if hasattr(history, 'history') and 'loss' in history.history else 'N/A'
    print(f"\nResults for {config['name']}:")
    print(f"  Test Loss: {test_loss:.4f}")
    print(f"  Test Accuracy: {test_accuracy:.4f}")
    print(f"  Test Micro F1: {test_f1_micro:.4f}")
    print(f"  Test Macro F1: {test_f1_macro:.4f}")
    print(f"  Duration: {duration:.2f} seconds")
    print(f"  Epochs Run: {epochs_run}")

    results_list.append({
        'Experiment Name': config['name'],
        'Model Type': 'BiLSTM',
        'Embedding Type': emb_type,
        'Embedding Dim': emb_dim,
        'Attention Used': config['use_attention'],
        'Test Loss': test_loss,
        'Test Accuracy': test_accuracy,
        'Test Micro F1': test_f1_micro,
        'Test Macro F1': test_f1_macro,
        'Training Time (s)': duration,
        'Epochs Run': epochs_run
    })

print("\n=== Finished BiLSTM Experiments ===")

# Transformer setup
TRANSFORMER_HEADS = 4
TRANSFORMER_FF_DIM = 256
TRANSFORMER_DROPOUT = 0.1
TRANSFORMER_LR = 3e-4
TRANSFORMER_EPOCHS = 15

transformer_experiments = [
    {'name': 'Transformer_Scratch_L1_Pos', 'embedding_type': 'scratch', 'num_blocks': 1, 'use_positional_emb': True},
    {'name': 'Transformer_Scratch_L2_Pos', 'embedding_type': 'scratch', 'num_blocks': 2, 'use_positional_emb': True},
    {'name': 'Transformer_Scratch_L3_Pos', 'embedding_type': 'scratch', 'num_blocks': 3, 'use_positional_emb': True},
    {'name': 'Transformer_Scratch_L1_noPos', 'embedding_type': 'scratch', 'num_blocks': 1, 'use_positional_emb': False},
    {'name': 'Transformer_Scratch_L2_noPos', 'embedding_type': 'scratch', 'num_blocks': 2, 'use_positional_emb': False},
    {'name': 'Transformer_Scratch_L3_noPos', 'embedding_type': 'scratch', 'num_blocks': 3, 'use_positional_emb': False},
    {'name': 'Transformer_word2vec_L1_Pos', 'embedding_type': 'word2vec', 'num_blocks': 1, 'use_positional_emb': True},
    {'name': 'Transformer_word2vec_L2_Pos', 'embedding_type': 'word2vec', 'num_blocks': 2, 'use_positional_emb': True},
    {'name': 'Transformer_word2vec_L3_Pos', 'embedding_type': 'word2vec', 'num_blocks': 3, 'use_positional_emb': True},
    {'name': 'Transformer_word2vec_L1_noPos', 'embedding_type': 'word2vec', 'num_blocks': 1, 'use_positional_emb': False},
    {'name': 'Transformer_word2vec_L2_noPos', 'embedding_type': 'word2vec', 'num_blocks': 2, 'use_positional_emb': False},
    {'name': 'Transformer_word2vec_L3_noPos', 'embedding_type': 'word2vec', 'num_blocks': 3, 'use_positional_emb': False},
    {'name': 'Transformer_glove_L1_Pos', 'embedding_type': 'glove', 'num_blocks': 1, 'use_positional_emb': True},
    {'name': 'Transformer_glove_L2_Pos', 'embedding_type': 'glove', 'num_blocks': 2, 'use_positional_emb': True},
    {'name': 'Transformer_glove_L3_Pos', 'embedding_type': 'glove', 'num_blocks': 3, 'use_positional_emb': True},
    {'name': 'Transformer_glove_L1_noPos', 'embedding_type': 'glove', 'num_blocks': 1, 'use_positional_emb': False},
    {'name': 'Transformer_glove_L2_noPos', 'embedding_type': 'glove', 'num_blocks': 2, 'use_positional_emb': False},
    {'name': 'Transformer_glove_L3_noPos', 'embedding_type': 'glove', 'num_blocks': 3, 'use_positional_emb': False},
    {'name': 'Transformer_fasttext_L1_Pos', 'embedding_type': 'fasttext', 'num_blocks': 1, 'use_positional_emb': True},
    {'name': 'Transformer_fasttext_L2_Pos', 'embedding_type': 'fasttext', 'num_blocks': 2, 'use_positional_emb': True},
    {'name': 'Transformer_fasttext_L3_Pos', 'embedding_type': 'fasttext', 'num_blocks': 3, 'use_positional_emb': True},
    {'name': 'Transformer_fasttext_L1_noPos', 'embedding_type': 'fasttext', 'num_blocks': 1, 'use_positional_emb': False},
    {'name': 'Transformer_fasttext_L2_noPos', 'embedding_type': 'fasttext', 'num_blocks': 2, 'use_positional_emb': False},
    {'name': 'Transformer_fasttext_L3_noPos', 'embedding_type': 'fasttext', 'num_blocks': 3, 'use_positional_emb': False}
]

transformer_results_list = []

print("\n=== Starting Transformer Experiments ===")
for config in transformer_experiments:
    print(f"\n{'='*10} Running Transformer Experiment: {config['name']} {'='*10}")
    start_time = time.time()
    emb_type = config['embedding_type']
    emb_info = embedding_matrices.get(emb_type)
    if not emb_info:
        print(f"Embedding info for '{emb_type}' not found. Skipping.")
        continue

    emb_matrix = emb_info['matrix']
    emb_dim = emb_info['dim']
    if emb_dim % TRANSFORMER_HEADS != 0:
        print(f"Embedding dim ({emb_dim}) not divisible by heads ({TRANSFORMER_HEADS}). Skipping.")
        continue

    freeze_embeddings = (emb_type != 'scratch' and emb_matrix is not None)

    tf.keras.backend.clear_session()
    model = TransformerClassifier(
        vocab_size=vocab_size,
        embed_dim=emb_dim,
        max_len=MAX_LEN,
        num_heads=TRANSFORMER_HEADS,
        ff_dim=TRANSFORMER_FF_DIM,
        num_transformer_blocks=config['num_blocks'],
        num_classes=num_classes,
        dropout_rate=TRANSFORMER_DROPOUT,
        embedding_matrix=emb_matrix,
        freeze_embeddings=freeze_embeddings,
        use_positional_emb=config['use_positional_emb'],
        name=config['name']
    )

    model.compile(
        optimizer=Adam(learning_rate=TRANSFORMER_LR),
        loss=SparseCategoricalCrossentropy(from_logits=True),
        metrics=[SparseCategoricalAccuracy(name='accuracy')]
    )

    try:
        model_graph = model.build_graph()
        print("\nModel Summary:")
        model_graph.summary()
    except Exception as e:
        print(f"Could not build graph for summary: {e}. Using default summary.")
        model.summary()

    print(f"\nTraining {config['name']}...")
    history = model.fit(
        X_train_np, y_train_np,
        validation_data=(X_test_np, y_test_np),
        epochs=TRANSFORMER_EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=[],
        verbose=0
    )
    print(f"\nEvaluating {config['name']}...")
    test_loss, test_accuracy = model.evaluate(X_test_np, y_test_np, batch_size=BATCH_SIZE*2, verbose=0)
    y_pred_logits = model.predict(X_test_np, batch_size=BATCH_SIZE*2)
    y_pred_classes = np.argmax(y_pred_logits, axis=1)
    test_f1_micro = f1_score(y_test_np, y_pred_classes, average='micro', zero_division=0)
    test_f1_macro = f1_score(y_test_np, y_pred_classes, average='macro', zero_division=0)

    end_time = time.time()
    duration = end_time - start_time
    epochs_run = len(history.history['loss']) if 'loss' in history.history else 'N/A'

    print(f"\nResults for {config['name']}:")
    print(f"  Test Loss: {test_loss:.4f}")
    print(f"  Test Accuracy: {test_accuracy:.4f}")
    print(f"  Test Micro F1: {test_f1_micro:.4f}")
    print(f"  Test Macro F1: {test_f1_macro:.4f}")
    print(f"  Duration: {duration:.2f} seconds")
    print(f"  Epochs Run: {epochs_run}")

    transformer_results_list.append({
        'Experiment Name': config['name'],
        'Model Type': 'Transformer',
        'Embedding Type': emb_type,
        'Embedding Dim': emb_dim,
        'Num Blocks': config['num_blocks'],
        'Positional Emb': config['use_positional_emb'],
        'Test Loss': test_loss,
        'Test Accuracy': test_accuracy,
        'Test Micro F1': test_f1_micro,
        'Test Macro F1': test_f1_macro,
        'Training Time (s)': duration,
        'Epochs Run': epochs_run
    })

    del model
    tf.keras.backend.clear_session()
    import gc
    gc.collect()

print("\n=== Finished Transformer Experiments ===")
print("\n\n" + "="*20 + " Final Experiment Results " + "="*20)
all_results = results_list + transformer_results_list
if not all_results:
    print("No experiments were successfully completed.")
else:
    results_df = pd.DataFrame(all_results)
    results_df = results_df.sort_values(by='Test Micro F1', ascending=False)
    print(results_df.to_markdown(index=False))
    results_filename = "combined_model_comparison_results2.csv"
    try:
        results_df.to_csv(results_filename, index=False)
        print(f"Results saved to {results_filename}")
    except Exception as e:
        print(f"Error saving results to CSV: {e}")

print("\nScript finished.")
