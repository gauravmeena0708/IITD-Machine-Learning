# How to install the environment

    pip install -r requirements.txt
    
# Download the embeddings 

Pre trained Embeddings has to be downloaded using gensim for comparison with Pre trained embeddings

# Run

    python final.py
